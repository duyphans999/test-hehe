package wq.atrax.publisher.nifi.monitoring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import wq.atrax.publisher.nifi.monitoring.entity.ExecutionLog;
import wq.atrax.publisher.nifi.monitoring.service.ExecutionLogService;

import java.util.List;

@RestController
public class ExecutionLogController {
    @Autowired
    ExecutionLogService executionLogService;

    @GetMapping("/execution-log/all")
    public List<ExecutionLog> listAll() {
        return executionLogService.getAll();
    }

}
