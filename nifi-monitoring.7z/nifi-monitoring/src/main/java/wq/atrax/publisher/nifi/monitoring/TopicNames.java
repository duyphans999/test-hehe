package wq.atrax.publisher.nifi.monitoring;

public interface TopicNames {
    String NIFI_EXECUTION_LOG = "nifi-execution-log";
}
