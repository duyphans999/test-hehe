package wq.atrax.publisher.nifi.monitoring.repository;

import org.springframework.data.repository.CrudRepository;
import wq.atrax.publisher.nifi.monitoring.entity.ExecutionLog;

public interface ExecutionLogRepository extends CrudRepository<ExecutionLog, Integer> {
}
