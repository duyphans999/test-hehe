package wq.atrax.publisher.nifi.monitoring.consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;
import wq.atrax.publisher.nifi.monitoring.TopicNames;
import wq.atrax.publisher.nifi.monitoring.entity.ExecutionLog;
import wq.atrax.publisher.nifi.monitoring.service.ExecutionLogService;

@Component
public class ExecutionLogConsumer {
    @Autowired
    ExecutionLogService executionLogService;

    @KafkaListener(topics = TopicNames.NIFI_EXECUTION_LOG, groupId = "foo")
    public void listenGroupFoo(String message) {
        System.out.println("Received Message in group foo: " + message);

        ExecutionLog executionLog = new ExecutionLog();
        executionLog.setMessage(message);
        executionLogService.saveOrUpdate(executionLog);
    }
}
