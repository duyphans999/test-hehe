package wq.atrax.publisher.nifi.monitoring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wq.atrax.publisher.nifi.monitoring.entity.ExecutionLog;
import wq.atrax.publisher.nifi.monitoring.repository.ExecutionLogRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class ExecutionLogService {
    @Autowired
    ExecutionLogRepository executionLogRepository;

    public List<ExecutionLog> getAll() {
        List<ExecutionLog> allLogs = new ArrayList<>();
        executionLogRepository.findAll().forEach(executionLog -> allLogs.add(executionLog));
        return allLogs;
    }

    public ExecutionLog getById(int id) {
        return executionLogRepository.findById(id).get();
    }

    public void saveOrUpdate(ExecutionLog executionLog) {
        executionLogRepository.save(executionLog);
    }
}
